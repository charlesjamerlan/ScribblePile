﻿
function nextPage() {
    location.href = "?p=" + (curpage + 1);
}

function prevPage() {
    location.href = "?p=" + (curpage - 1);
}

function jumpTo(url) {
    location.href = url;
}


function IsValidFileSize(fileid, max) {
    try {
        var fileSize = 0;
        //for IE
        if ($.browser.msie) {
            //before making an object of ActiveXObject, 
            //please make sure ActiveX is enabled in your IE browser
            var objFSO = new ActiveXObject("Scripting.FileSystemObject"); var filePath = $("#" + fileid)[0].value;
            var objFile = objFSO.getFile(filePath);
            var fileSize = objFile.size; //size in kb
            fileSize = fileSize / 1048576; //size in mb 
        }
            //for FF, Safari, Opeara and Others
        else {
            fileSize = $("#" + fileid)[0].files[0].size //size in kb
            fileSize = fileSize / 1048576; //size in mb 
        }
        //alert("Uploaded File Size is" + fileSize + "MB");
        if (fileSize > max) {
            return false;
        }
        else {
            return true;
        }
    }
    catch (e) {
        return false;
    }
}

function IsValidFileType(fileid) {
    var ext = $('#' + fileid + '').val().split('.').pop().toLowerCase();
    if (ext != '') {
        if ($.inArray(ext, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
            return false;
        }
        else {
            return true;
        }
    }
    else {
        return true;
    }
}

function IsValidFileUpload(fileid, max) {
    var rtn = false;
    var validtype = IsValidFileType(fileid);
    if (validtype) {
        var filename = $('#' + fileid).val();
        if (filename != '') {
            var validFileSize = IsValidFileSize(fileid, max);
            if (validFileSize) {
                rtn = true;
            }
        }
        else {
            rtn = true;
        }
    }
    return rtn;
}

function ProcessSubmission(btn) {

    ValidateImageUpload();

    if ($('#scribbleform').parsley().isValid()) {
        $('#invalidfile_message_dropzone').fadeOut('fast');

        btn.value = 'Processing Submission';
        $(btn).removeClass('blue').addClass('green');
        btn.disabled = 'disabled';
        btn.form.submit();
    }

}

function ValidateImageUpload() {
    if ($('#filename').val() == '') {
        $('#invalidfile_message_dropzone').fadeIn('fast');
    }
    else {
        $('#invalidfile_message_dropzone').fadeOut('fast');
    }
}


function RemoveImage() {
    $('#image_remove').val('1');
    $('#profileimage').slideUp();
}
