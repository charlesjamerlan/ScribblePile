﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace scribble.Controllers
{
    public class ContentController : Controller
    {

        public ActionResult About()
        {
            return View("about");
        }

        public ActionResult Terms()
        {
            return View("terms");
        }
        public ActionResult Privacy()
        {
            return View("privacy");
        }

    }
}
