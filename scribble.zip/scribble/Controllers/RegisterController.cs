﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using scribble.Models;
using scribble.Common;

namespace scribble.Controllers
{
    public class RegisterController : Controller
    {
        public ActionResult Index()
        {
            if (Utilities.IsAuthenticated())
            {
                return Redirect("/user/" + Utilities.GetLoggedInUserID().ToString());
            }
            return View("register");
        }

        [HttpPost]
        public ActionResult CompleteInvitation(FormCollection form)
        {
            string invitation_code = form["invitation_code"];

            if (!string.IsNullOrEmpty(invitation_code))
            {
                InvitationCode invitecode = Models.User.GetUserValidInvitationCode(invitation_code);
                if (invitecode == null)
                {
                    return Redirect("/register/completeinvitation?s=false&m=invitecode");
                }
                else
                {
                    Models.User.SetAccountType(1, invitecode.id_user);
                    InvitationCode.SetInvitationCodeRedeemed(invitation_code, invitecode.id_user);
                    return Redirect("/register/completeinvitation?s=true");
                }
            }
            else
            {
                return Redirect("/register/completeinvitation?s=false&m=invitecode");
            }
        }

        public ActionResult CompleteInvitation()
        {
            return View("completeinvitation");
        }

        [HttpPost]
        public ActionResult RequestInvitation(FormCollection form)
        {
            string username = form["username"];
            User u = new User(username);
            if (u.id > 0)
            {
                //update account
                Models.User.MarkAsRequested(username);

                //send email to user
                string template = ViewRenderer.RenderView("~/views/EmailTemplate/requestinvitation.cshtml", u, ControllerContext);
                Notifications.SendEmail("charles@scribblepile.com", "donotreply@scribblepile.com", "ScribblePile - Invitation Request", template);
                return Redirect("/register/requestinvitation?s=true");
            }
            else
            {
                return Redirect("/register/requestinvitation?s=false&m=username");
            }
        }

        public ActionResult RequestInvitation()
        {
            return View("requestinvitation");
        }

        [HttpPost]
        public ActionResult Index(FormCollection form)
        {
            string firstname = form["firstname"];
            string lastname = form["lastname"];
            string username = form["username"];
            string email = form["email"];
            string password = Utilities.SHA512Hash( form["password"] + System.Configuration.ConfigurationManager.AppSettings["saltvalue"]);
            string registertype = form["registertype"];
            string invitation_code = form["invitation_code"];

            bool validcode = false;

            if (!string.IsNullOrEmpty(invitation_code))
            {
                validcode = Models.User.ValidInvitationCode(invitation_code);
                if (!validcode)
                {
                    return Redirect("/register?success=false&m=invitecode");
                }
            }

            User user = Models.User.Get(username);
            if (user.id > 0)
            {
                return Redirect("/register?success=false&m=username");
            }
            else
            {
                //check if email exists
                if (Models.User.EmailExists(email))
                {
                    return Redirect("/register?success=false&m=email");
                }
                else
                {
                    int newid = Models.User.Register(username, firstname, lastname, password, email, invitation_code);
                    user = Models.User.Get(newid);
                    int openregistration = int.Parse(System.Configuration.ConfigurationManager.AppSettings["OpenRegistration"]);
                    if (openregistration == 1)
                    {
                        validcode = true; //override for now
                        invitation_code = System.Configuration.ConfigurationManager.AppSettings["OpenRegistrationCode"];
                    }
                    if (validcode)
                    {
                        Models.User.SetAccountType(1, newid);
                        InvitationCode.SetInvitationCodeRedeemed(invitation_code, newid);
                    }
                    //send email to user
                    try
                    {
                        string template = ViewRenderer.RenderView("~/views/EmailTemplate/registration.cshtml", user, ControllerContext);
                        Notifications.SendEmail(user.email, "donotreply@scribblepile.com", "ScribblePile - Thanks for signing up!", template);
                    }
                    catch (Exception e)
                    {
                    }

                    FormsAuthentication.SetAuthCookie(newid.ToString(), false);
                    return Redirect("/user/" + newid.ToString() + "?register=true");
                }
            }

        }
    }
}
