﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using scribble.Models;
using scribble.Common;

namespace scribble.Controllers
{
    public class UserController : Controller
    {
        public class UserControllerModel
        {
            public User user { get; set; }
            public IList<Scribble> scribbles { get; set; }
            public string filter_type { get; set; }
            public string filter_description { get; set; }

            public UserControllerModel()
            {
                user = null;
                scribbles = null;
                filter_type = string.Empty;
                filter_description = string.Empty;
            }
        }

        public class UserControllerCommissionModel
        {
            public User user { get; set; }
            public CommissionInformation commissioninformation { get; set; }

            public UserControllerCommissionModel()
            {
                user = null;
                commissioninformation = null;
            }
        }

        public ActionResult CommissionList(int id_user)
        {
            UserControllerCommissionModel uccm = new UserControllerCommissionModel();
            uccm.user = scribble.Models.User.Get(id_user);
            uccm.commissioninformation = scribble.Models.CommissionInformation.GetCommissionInformation(id_user);
            return View("commissionlist", uccm);
        }

        public ActionResult CommissionRequest(int id_user)
        {
            return View("commissionrequest");
        }


        public ActionResult Favorites(int id_user)
        {
            int start = 1;
            int perpage = int.Parse(System.Configuration.ConfigurationManager.AppSettings["PerPage"]);

            if (!String.IsNullOrEmpty(Request.QueryString["p"]))
            {
                start = int.Parse(Request.QueryString["p"]);
                if (start > 0)
                {
                    //start = start * perpage + 1;
                    start = start + 1;
                }
                else
                {
                    start = 1;
                }
            }

            UserControllerModel ucm = new UserControllerModel();
            ucm.user = scribble.Models.User.Get(id_user);
            ucm.scribbles = scribble.Models.Scribble.GetScribblesFavorteByUser(id_user, start);
            ucm.filter_type = "favorites";
            ucm.filter_description = "favorited";

            if (ucm.user.id == 0)
            {
                return View("notfound");
            }
            return View("profile", ucm);
        }

        public ActionResult Get(string id_user)
        {
            int start = 1;
            int perpage = int.Parse(System.Configuration.ConfigurationManager.AppSettings["PerPage"]);

            if(!String.IsNullOrEmpty(Request.QueryString["p"])){
                start = int.Parse(Request.QueryString["p"]);
                if (start > 0)
                {
                    start = start + 1;
                }
                else
                {
                    start = 1;
                }
            }

            UserControllerModel ucm = new UserControllerModel();

            int userid = 0;
            if (!String.IsNullOrEmpty(id_user))
            {
                if (int.TryParse(id_user, out userid))
                {
                    ucm.user = scribble.Models.User.Get(userid);
                }
                else
                {
                    ucm.user = scribble.Models.User.Get(id_user);
                }
            }

            //if not a pro user, then redirect to favorites
            User current_user = Utilities.GetLoggedInUser();
            if ((ucm.user.account_type != 1) && (ucm.user.id == current_user.id)){
                return Redirect("/user/" + ucm.user.id.ToString() + "/favorites");
            }

            ucm.filter_type = "owner";
            ucm.filter_description = "posted";

            ucm.scribbles = scribble.Models.Scribble.GetScribblesByUser(ucm.user.id, start);

            if (ucm.user.id == 0)
            {
                return View("notfound");
            }
            return View("profile", ucm);
        }

        [CustomAttributes.CheckAuthor]
        public ActionResult Edit(int id_user)
        {
            User u = scribble.Models.User.Get(id_user);
            return View("edit", u);
        }

        [HttpPost]
        public ActionResult Edit(int id_user, FormCollection form)
        {
            string firstname = form["firstname"];
            string lastname = form["lastname"];
            string email = form["email"];
            string biography = form["biography"];
            string website = form["website"];
            string image_remove = form["image_remove"];
            string username = form["username"].CleanUsername();

            if (id_user > 0)
            {
                Models.User user = Models.User.Get(id_user);
                if (user.email != email)
                {
                    if (Models.User.EmailExists(email))
                    {
                        return Redirect("/user/" + id_user.ToString() + "/edit?s=false&m=email");
                    }
                }

                if (user.username != username)
                {
                    if (Models.User.UsernameExists(username))
                    {
                        return Redirect("/user/" + id_user.ToString() + "/edit?s=false&m=username");
                    }
                }

                var file = Request.Files[0];
                if (file != null && file.ContentLength > 0)
                {
                    //let's check for filesize type
                    int maxfileupload = int.Parse(System.Configuration.ConfigurationManager.AppSettings["MaxFileUploadSize"]);

                    if (!Utilities.IsValidImageContentType(file.ContentType))
                    {
                        return Redirect("/user/"+id_user+"/edit?s=false&m=invalidfiletype");
                    }
                    else if ((file.ContentLength / 1048576) > maxfileupload)
                    {
                        return Redirect("user/" + id_user + "/edit??s=false&m=invalidfilesize");
                    }

                    var guid = Guid.NewGuid().ToString();
                    var fileName = guid + "_" + Path.GetFileName(file.FileName);

                    fileName = id_user.ToString() + ".jpg";
                    var path = Path.Combine(Server.MapPath("~/Users/"), fileName);
                    file.SaveAs(path);

                    //resize image for thumbnails
                    Utilities.ResizeImage(fileName, Server.MapPath("~/Users/"));
                    user.photo = true;
                }
                else if (!String.IsNullOrEmpty(image_remove))
                {
                    user.photo = false;
                }

                user.firstname = firstname;
                user.lastname = lastname;
                user.email = email;
                user.username = username;
                user.biography = biography;
                user.website = website;
                user.UpdateProfile();

            }

            return Redirect("/user/" + id_user.ToString() + "/edit?s=true");
        }
    }
}
