﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using scribble.Common;
using scribble.Models;

namespace scribble.Controllers
{
    public class AdminController : Controller
    {
        [CustomAttributes.CheckAdminType]
        [Authorize]
        public ActionResult Stats()
        {
            return View("stats");
        }

        [CustomAttributes.CheckAdminType]
        [Authorize]
        public ActionResult ApproveRequest()
        {
            int id_user = int.Parse(Request.QueryString["id"]);
            Models.User.ApproveRequest(id_user);
            InvitationCode invitationcode = InvitationCode.GenerateInvitationCode(id_user);

            Models.User u = Models.User.Get(id_user);

            //send email out
            string template = ViewRenderer.RenderView("~/views/EmailTemplate/completeinvitation.cshtml", invitationcode, ControllerContext);
            Notifications.SendEmail(u.email, "charles@scribblepile.com", "ScribblePile - Request Approved!", template);
            return Redirect("/admin/stats?f=approved");
        }

        [CustomAttributes.CheckAdminType]
        [Authorize]
        public ActionResult EmailViewer()
        {
            InvitationCode invitationcode = InvitationCode.GenerateInvitationCode(1);

            string template = ViewRenderer.RenderView("~/views/EmailTemplate/completeinvitation.cshtml", invitationcode, ControllerContext);
            Notifications.SendEmail("charles@charlesjamerlan.com", "charles@scribblepile.com", "ScribblePile - Request Approved!", template);


            return View("~/Views/EmailTemplate/completeinvitation.cshtml", invitationcode);
        }
    }
}
