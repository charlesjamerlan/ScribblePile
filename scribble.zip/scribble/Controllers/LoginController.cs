﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using scribble.Models;
using scribble.Common;

namespace scribble.Controllers
{
    public class LoginController : Controller
    {
        public ActionResult Index()
        {
            if (Utilities.IsAuthenticated())
            {
                if ((Request.QueryString["f"] == "sso") && (Request.QueryString["success"] == "true"))
                {
                    Response.Write("<script>window.close();</script>");
                }
                else
                {
                    string redirect = Request.QueryString["r"];
                    if (string.IsNullOrEmpty(redirect))
                    {
                        redirect = "/";
                    }
                    return Redirect(redirect);

                }                
            }
            return View("login");
        }

        [HttpPost]
        public ActionResult ForgotPassword(FormCollection form)
        {
            string username = form["username"];
            User u = new User(username);
            u.SetResetToken();

            bool status = false;
            if (u.id > 0)
            {
                //send email to user
                string template = ViewRenderer.RenderView("~/views/EmailTemplate/forgotpassword.cshtml", u, ControllerContext);
                Notifications.SendEmail(u.email, "donotreply@scribblepile.com", "ScribblePile - Forgot Your Password", template);
                status = true;
            }            
            return Redirect("/login/forgotpassword?s=" + status.ToString().ToLower());
        }

        public ActionResult ForgotPassword()
        {
            return View("forgotpassword");
        }


        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();

            // clear authentication cookie
            HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
            cookie1.Domain = "scribblepile.com";
            cookie1.Expires = DateTime.Now.AddYears(-1);
            Response.Cookies.Add(cookie1);

            // clear session cookie (not necessary for your current problem but i would recommend you do it anyway)
            HttpCookie cookie2 = new HttpCookie("ASP.NET_SessionId", "");
            cookie2.Domain = "scribblepile.com";
            cookie2.Expires = DateTime.Now.AddYears(-1);
            Response.Cookies.Add(cookie2);

            return Redirect("/login");
        }

        [HttpPost]
        public ActionResult Index(FormCollection form)
        {
            string username = form["username"];
            string password = form["password"];
            string redirect = Request.QueryString["r"];
            string from = Request.QueryString["f"];

            if (string.IsNullOrEmpty(redirect))
            {
                redirect = "/user/" + username;
            }

            password = Utilities.SHA512Hash(password + System.Configuration.ConfigurationManager.AppSettings["saltvalue"]);
            int id_user = Models.User.Login(username, password);
            if (id_user > 0)
            {
                FormsAuthentication.SetAuthCookie(id_user.ToString(), false);
                System.Web.HttpCookie authcookie = System.Web.Security.FormsAuthentication.GetAuthCookie(id_user.ToString(),true);
                authcookie.Domain = "scribblepile.com";
                Response.AppendCookie(authcookie);  
                //determine redirect
                if (from == "sso")
                {
                    redirect = "/login?success=true&f=sso";
                }
                return Redirect(redirect);
            }
            else
            {
                return Redirect("/login?success=false&f="+from+"&r="+redirect);
            }
        }

    }
}
