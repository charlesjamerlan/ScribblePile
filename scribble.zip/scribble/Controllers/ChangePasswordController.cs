﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using scribble.Models;
using scribble.Common;

namespace scribble.Controllers
{
    public class ChangePasswordController : Controller
    {

        [HttpPost]
        public ActionResult Index(FormCollection form)
        {
            int userid = int.Parse(form["userid"]);
            string password = form["newpassword"];
            string confirmpassword = form["confirmpassword"];
            bool status = false;

            if (password == confirmpassword)
            {
                password = Utilities.SHA512Hash(password + System.Configuration.ConfigurationManager.AppSettings["saltvalue"]);
                scribble.Models.User.ChangePassword(password, userid);
                status = true;
            }

            return Redirect("/changepassword?s=" + status.ToString().ToLower());
        }


        public ActionResult Index()
        {
            string id = Request.QueryString["id"];
            if (string.IsNullOrEmpty(id))
            {
                return Redirect("/login");
            }
            else
            {
                string status = Request.QueryString["s"];
                if (status != "true")
                {
                    string token = Request.QueryString["token"];
                    User u = new User(int.Parse(id));

                    if (u.reset_token != token)
                    {
                        return Redirect("/login");
                    }
                }
            }
            return View("changepassword");
        }

    }
}
