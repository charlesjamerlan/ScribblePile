﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using scribble.Models;

namespace scribble.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            int start = 1;
            int perpage = int.Parse(System.Configuration.ConfigurationManager.AppSettings["PerPage"]);

            if (!String.IsNullOrEmpty(Request.QueryString["p"]))
            {
                start = int.Parse(Request.QueryString["p"]);
                if (start > 0)
                {
                    //start = start * perpage + 1;
                    start = start + 1;
                }
                else
                {
                    start = 1;
                }
            }
            IList<Scribble> scribbles = Scribble.GetScribblesMostRecent(start);
            return View("home", scribbles);
        }

        public ActionResult HashTags(string tag)
        {
            int start = 1;
            int perpage = int.Parse(System.Configuration.ConfigurationManager.AppSettings["PerPage"]);

            if (!String.IsNullOrEmpty(Request.QueryString["p"]))
            {
                start = int.Parse(Request.QueryString["p"]);
                if (start > 0)
                {
                    start = start * perpage + 1;
                }
                else
                {
                    start = 1;
                }
            }

            IList<Scribble> scribbles = Scribble.GetScribblesByHashTag(start, tag);
            return View("hashtags", scribbles);
        }

        public ActionResult Popular()
        {
            int start = 1;
            int perpage = int.Parse(System.Configuration.ConfigurationManager.AppSettings["PerPage"]);

            if (!String.IsNullOrEmpty(Request.QueryString["p"]))
            {
                start = int.Parse(Request.QueryString["p"]);
                if (start > 0)
                {
                    //start = start * perpage + 1;
                    start = start + 1;
                }
                else
                {
                    start = 1;
                }
            }

            IList<Scribble> scribbles = Scribble.GetScribblesMostPopular(start);
            return View("home", scribbles);
        }

        public ActionResult Latest()
        {
            int start = 1;
            int perpage = int.Parse(System.Configuration.ConfigurationManager.AppSettings["PerPage"]);

            if (!String.IsNullOrEmpty(Request.QueryString["p"]))
            {
                start = int.Parse(Request.QueryString["p"]);
                if (start > 0)
                {
                    //start = start * perpage + 1;
                    start = start + 1;
                }
                else
                {
                    start = 1;
                }
            }
            IList<Scribble> scribbles = Scribble.GetScribblesMostRecent(start);
            return View("home", scribbles);
        }
    }
}
