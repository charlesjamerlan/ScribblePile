﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using scribble.Models;
using scribble.Common;
using System.IO;
using System.Web.Script.Serialization;

namespace scribble.Controllers
{
    public class ScribbleController : Controller
    {
        public class ScribbleControllerModel
        {
            public Scribble scribble { get; set; }
            public User user_loggedin { get; set; }
            public string disqus_sso_payload { get; set; }
            public bool is_owner { get; set; }
            public bool is_liked { get; set; }
            public bool is_favorited { get; set; }

            public ScribbleControllerModel()
            {
                scribble = null;
                user_loggedin = null;
                disqus_sso_payload = string.Empty;
                is_owner = false;   
            }
        }

        [Authorize]
        public ActionResult UpdateCommentCount(string id_scribble)
        {
            scribble.Models.Scribble.UpdateCommentCount(int.Parse(id_scribble));
            return Json(new { success = true }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        public ActionResult Liked(string id_scribble)
        {
            scribble.Models.Like.SaveLike(int.Parse(id_scribble), Utilities.GetLoggedInUserID());
            return Json(new { success = true }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        public ActionResult Unlike(string id_scribble)
        {
            scribble.Models.Like.RemoveLike(int.Parse(id_scribble), Utilities.GetLoggedInUserID());
            return Json(new { success = true }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        public ActionResult Favorited(string id_scribble)
        {
            scribble.Models.Favorite.SaveFavorite(int.Parse(id_scribble), Utilities.GetLoggedInUserID());
            return Json(new { sucess = true }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        public ActionResult UnFavorite(string id_scribble)
        {
            scribble.Models.Favorite.RemoveFavorite(int.Parse(id_scribble), Utilities.GetLoggedInUserID());
            return Json(new { sucess = true }, JsonRequestBehavior.AllowGet);
        }

        [CustomAttributes.CheckScribbleAttribute]
        public ActionResult Edit(string id_scribble)
        {
            Scribble s = Scribble.Get(id_scribble);
            return View(s);
        }


        [CustomAttributes.CheckScribbleAttribute]
        [HttpPost]
        public ActionResult Edit(string id_scribble, FormCollection form)
        {
            string title = form["title"];
            string description = form["description"];

            Scribble s = Scribble.Get(id_scribble);
            s.title = title;
            s.description = description;
            s.Save();

            //process hashtags
            Utilities.ClearHashTags(s.id);
            Utilities.ProcessHashTags(s.description, s.id);

            return Redirect("/scribble/" + s.id.ToString());
        }

        [CustomAttributes.CheckScribbleAttribute]
        [Authorize]
        public ActionResult Delete(string id_scribble)
        {
            User u = Utilities.GetLoggedInUser();
            Scribble s = Scribble.Get(id_scribble);
            if (s.id_author == u.id)
            {
                s.Delete();
                u.UpdateCounts();
            }
            return Redirect("/user/" + u.id.ToString() + "?f=delete");

        }

        [CustomAttributes.CheckAccountType]
        public ActionResult Add()
        {
            return View();
        }

        [CustomAttributes.CheckAccountType]
        public ActionResult AddVersion(string id_scribble)
        {            
            Scribble s = Scribble.Get(id_scribble);
            return View("addversion",null, s);
        }


        [CustomAttributes.CheckScribbleAttribute]
        [HttpPost]
        public ActionResult AddVersion(string id_scribble, FormCollection form)
        {
            string title = form["title"];
            string description = form["description"];

            if (int.Parse(id_scribble) > 0)
            {
                
                //check first if you have reachead limitt
                int maxversions = int.Parse(System.Configuration.ConfigurationManager.AppSettings["MaxVersions"]);
                if (Scribble.GetVersionCount(int.Parse(id_scribble)) >= maxversions)
                {
                    return Redirect("/scribble/add?s=false&m=maxversions");
                }

                //var file = Request.Files[0];
                //if (file != null && file.ContentLength > 0)
                //{
                //    //let's check for filesize type
                //    int maxfileupload = int.Parse(System.Configuration.ConfigurationManager.AppSettings["MaxFileUploadSize"]);
                //    if (!Utilities.IsValidImageContentType(file.ContentType))
                //    {
                //        return Redirect("/scribble/add?s=false&m=invalidfiletype");
                //    }
                //    else if ((file.ContentLength / 1048576) > maxfileupload)
                //    {
                //        return Redirect("/scribble/add?s=false&m=invalidfilesize");
                //    }

                //    var guid = Guid.NewGuid().ToString();
                //    var fileName = guid + "_" + Path.GetFileName(file.FileName);
                //    //Common.Utilities.ResizeImage(file.InputStream, fileName);

                //    var path = Path.Combine(Server.MapPath("~/Scribbles/"), fileName);
                //    file.SaveAs(path);
                //    Utilities.UploadImage(fileName, Server.MapPath("~/Scribbles/"));

                //    //resize image for thumbnails
                //    Utilities.ResizeImage(fileName, Server.MapPath("~/Scribbles/"));


                //}

                string fileName = form["filename"];
                Models.Version version = new Models.Version();
                version.description = description;
                version.filename = fileName.Replace(".png", ".jpg").Replace(".gif", ".jpg").Replace(" ", "_");
                version.scribble_id = int.Parse(id_scribble);
                version.Add();

                //process hashtags
                Utilities.ProcessHashTags(version.description, version.scribble_id);

            }

            return Redirect("/scribble/" + id_scribble.ToString());
        }

        [CustomAttributes.CheckAccountType]
        public ActionResult DeleteVersion(string id_scribble)
        {
            string vid = Request.QueryString["vid"];
            User u = Utilities.GetLoggedInUser();
            Scribble s = Scribble.Get(id_scribble);
            if (s.id_author == u.id)
            {
                Models.Version version = Models.Version.Get(vid);
                version.Delete();
            }
            return Redirect("/scribble/" + id_scribble.ToString());
        }

        [CustomAttributes.CheckAccountType]
        public ActionResult EditVersion(string id_scribble)
        {
            Scribble s = Scribble.Get(id_scribble);
            return View("editversion", null, s);
        }

        [CustomAttributes.CheckScribbleAttribute]
        [HttpPost]
        public ActionResult EditVersion(string id_scribble, FormCollection form)
        {
            string description = form["description"];
            string vid = Request.QueryString["vid"];

            if (int.Parse(id_scribble) > 0)
            {

                Models.Version version = Models.Version.Get(vid);
                version.description = description;
                version.Save();

                //process hashtags
                Utilities.ProcessHashTags(version.description, version.scribble_id);

                
            }

            return Redirect("/scribble/" + id_scribble.ToString() + "#" + vid);
        }

        public ActionResult SaveUploadedFile()
        {
            bool isSavedSuccessfully = true;
            string fName = "";
            try
            {
                foreach (string fileName in Request.Files)
                {
                    HttpPostedFileBase file = Request.Files[fileName];
                    //Save file content goes here
                    fName = file.FileName;
                    if (file != null && file.ContentLength > 0)
                    {
                        var guid = Guid.NewGuid().ToString();
                        var imageFileName = guid + "_" + Path.GetFileName(file.FileName);

                        var path = Path.Combine(Server.MapPath("~/Scribbles/"), imageFileName);
                        file.SaveAs(path);
                        Utilities.UploadImage(imageFileName, Server.MapPath("~/Scribbles/"));

                        //resize image for thumbnails
                        Utilities.ResizeImage(imageFileName, Server.MapPath("~/Scribbles/"));

                        fName = imageFileName;
                    }
                }

            }
            catch (Exception ex)
            {
                isSavedSuccessfully = false;
            }

            if (isSavedSuccessfully)
            {
                return Json(new { Message = "Success", fileName = fName });
            }
            else
            {
                return Json(new { Message = "Error in saving file", fileName = "" });
            }
        }

        [HttpPost]
        public ActionResult Add(FormCollection form)
        {
            string title = form["title"];
            string description = form["description"];
           
            Scribble scribble = new Scribble();
            scribble.title = title;
            scribble.description = description;
            scribble.id_author = Utilities.GetLoggedInUserID();

            int id_scribble = scribble.Add();
            if (id_scribble > 0)
            {
                //var file = Request.Files[0];
                //if (file != null && file.ContentLength > 0)
                //{
                //    //let's check for filesize type
                //    int maxfileupload = int.Parse(System.Configuration.ConfigurationManager.AppSettings["MaxFileUploadSize"]);
                //    if (!Utilities.IsValidImageContentType(file.ContentType))
                //    {
                //        return Redirect("/scribble/add?s=false&m=invalidfiletype");
                //    }
                //    else if ((file.ContentLength/1048576) > maxfileupload)
                //    {
                //        return Redirect("/scribble/add?s=false&m=invalidfilesize");
                //    }

                //    var guid = Guid.NewGuid().ToString();
                //    var fileName = guid + "_" + Path.GetFileName(file.FileName);
                    
                //    var path = Path.Combine(Server.MapPath("~/Scribbles/"), fileName);
                //    file.SaveAs(path);
                //    Utilities.UploadImage(fileName, Server.MapPath("~/Scribbles/"));

                //    //resize image for thumbnails
                //    Utilities.ResizeImage(fileName, Server.MapPath("~/Scribbles/"));

                //    Models.Version version = new Models.Version();
                //    version.description = description;
                //    version.filename = fileName.Replace(".png", ".jpg").Replace(".gif", ".jpg").Replace(" ", "_");
                //    version.scribble_id = id_scribble;
                //    version.Add();

                //    //process hashtags
                //    Utilities.ProcessHashTags(version.description, version.scribble_id);
                //}

                string fileName = form["filename"];
                Models.Version version = new Models.Version();
                version.description = description;
                version.filename = fileName.Replace(".png", ".jpg").Replace(".gif", ".jpg").Replace(" ", "_");
                version.scribble_id = id_scribble;
                version.Add();

                //process hashtags
                Utilities.ProcessHashTags(version.description, version.scribble_id);
            }

            return Redirect("/scribble/" + id_scribble.ToString());
            
        }

        public ActionResult Get(string id_scribble)
        {
            string domain = System.Configuration.ConfigurationManager.AppSettings["Domain"];

            if (!Utilities.IsNumeric(id_scribble))
            {
                return View("notfound");
            }

            //Track View 
            View v = new View();
            v.id_scribble = int.Parse(id_scribble);
            v.ip = Request.UserHostAddress;
            v.useragent = Request.UserAgent;
            v.sessionid = Session.SessionID;
            v.Save();

            ScribbleControllerModel scm = new ScribbleControllerModel();
            Scribble s = Scribble.Get(id_scribble);
            scm.scribble = s;

            if (s.id == 0)
            {
                return View("notfound");
            }
            //authenticate if logged in
            User u = Utilities.GetLoggedInUser();
            scm.user_loggedin = new User();
            if (u.id > 0)
            {
                scm.user_loggedin = u;
                scm.is_owner = (u.id == s.author.id) ? true : false;
                scm.is_liked = Like.IsLiked(s.id, u.id);
                scm.is_favorited = Favorite.IsFavorited(s.id, u.id);
                var obj = new
                {
                    id = u.id,
                    username = u.username,
                    email = u.email,
                    about = u.biography,
                    avatar = "http://" + domain + "/Users/t_" + u.photo_name,
                    url = u.website
                };
                scm.disqus_sso_payload = Utilities.GenerateDisqusSSOPayload(obj);
            }
            return View("scribble",scm);
        }     

    }
}
