﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using scribble.Models;

namespace scribble.Common
{
    public class CustomAttributes
    {
        public class CheckAuthorAttribute : ActionFilterAttribute
        {
            public override void OnActionExecuting(ActionExecutingContext filterContext)
            {
                User user = Utilities.GetLoggedInUser();
                string userparameter = filterContext.RouteData.Values["id_user"].ToString();
                if (user.id != int.Parse(userparameter))
                {
                    var routeValues = new RouteValueDictionary(new
                    {
                        controller = "user",
                        action = "get",
                        id_user = user.username
                    });
                    filterContext.Result = new RedirectToRouteResult(routeValues);
                }
            }

        }


        public class CheckAccountTypeAttribute : ActionFilterAttribute
        {
            public override void OnActionExecuting(ActionExecutingContext filterContext)
            {
                User user = Utilities.GetLoggedInUser();      
                //if user is not allowed to upload, then redirect them to profile
                if (user.account_type == 0)
                {
                    var routeValues = new RouteValueDictionary(new
                    {
                        controller = "user",
                        action = "get",
                        id_user = user.username
                    });
                    filterContext.Result = new RedirectToRouteResult(routeValues);
                }
            }

        }


        public class CheckAdminTypeAttribute : ActionFilterAttribute
        {
            public override void OnActionExecuting(ActionExecutingContext filterContext)
            {
                User user = Utilities.GetLoggedInUser();
                //if user is not allowed to upload, then redirect them to profile
                if (!user.admin)
                {
                    var routeValues = new RouteValueDictionary(new
                    {
                        controller = "home",
                        action = "index"
                    });
                    filterContext.Result = new RedirectToRouteResult(routeValues);
                }
            }

        }


        public class CheckScribbleAttribute : ActionFilterAttribute
        {
            public override void OnActionExecuting(ActionExecutingContext filterContext)
            {
                User user = Utilities.GetLoggedInUser();
                string id_scribble = filterContext.RouteData.Values["id_scribble"].ToString();
                Scribble s = Scribble.Get(id_scribble);

                if (user.id != s.id_author)
                {
                    var routeValues = new RouteValueDictionary(new
                    {
                        controller = "user",
                        action = "get",
                        id_user = user.username
                    });
                    filterContext.Result = new RedirectToRouteResult(routeValues);
                }
            }

        }
    }
}