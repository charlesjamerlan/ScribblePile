﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Mail;
using scribble.Models;

namespace scribble.Common
{
    public static class Notifications
    {
        public static void SendEmail(string ToEmail, string FromEmail, string Subject, string HTMLBody)
        {
            MailMessage mailMessage = new MailMessage();
            mailMessage.To.Add(new MailAddress(ToEmail));
            mailMessage.From = new MailAddress(FromEmail);
            mailMessage.Subject = Subject;
            mailMessage.Body = HTMLBody;
            mailMessage.IsBodyHtml = true;
            mailMessage.Bcc.Add("charles@scribblepile.com");

            SmtpClient smtpClient = new SmtpClient();
            smtpClient.UseDefaultCredentials = true;
            //smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.Host = "localhost";
            smtpClient.Port = 25;
            smtpClient.Send(mailMessage);
        }        
    }
}