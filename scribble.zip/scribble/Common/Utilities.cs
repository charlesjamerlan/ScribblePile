﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using scribble.Models;
using System.Text;
using System.Security.Cryptography;
using System.Web.Script.Serialization;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Text.RegularExpressions;
using ImageResizer;
using scribble.Data;

namespace scribble.Common
{
    public static class Extensions
    {
        public static string CleanSQL(this String str)
        {
            return str.Replace("'", "''");
        }

        public static string CleanUsername(this String str)
        {
            return str.Replace("'", "").Replace(" ","_");
        }

        public static string TrimLiteral(this String str)
        {
            int max = 28;
            if (str.Length > max)
            {
                return str.Substring(0, max) + "...";
            }
            return str;
        }
    }

    public class Utilities
    {
        public static User GetLoggedInUser()
        {
            User u = new User();
            if (!String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
            {
                u = User.Get(int.Parse(HttpContext.Current.User.Identity.Name));
            }
            return u;
        }

        public static int GetLoggedInUserID()
        {
            int userid = 0;
            if (!String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
            {
                userid = int.Parse(HttpContext.Current.User.Identity.Name);
            }
            return userid;
        }

        public static string SHA512Hash(string stringtohash)
        {
            byte[] data = System.Text.Encoding.Default.GetBytes(stringtohash);
            byte[] result;
            SHA512 shaM = new SHA512Managed();
            result = shaM.ComputeHash(data);
            return BitConverter.ToString(result).Replace("-", "").ToLower();
        }
      
        public static bool IsAuthenticated()
        {
            return HttpContext.Current.User.Identity.IsAuthenticated;
        }

        public static bool IsNumeric(string val)
        {
            int n;
            bool isNumber = int.TryParse(val, out n);
            return isNumber;
        }

        public static string HMACSH1(string signatureString)
        {
            var enc = Encoding.ASCII;
            HMACSHA1 hmac = new HMACSHA1(enc.GetBytes(System.Configuration.ConfigurationManager.AppSettings["Disqus_Secret"]));
            hmac.Initialize();

            byte[] buffer = enc.GetBytes(signatureString);
            return BitConverter.ToString(hmac.ComputeHash(buffer)).Replace("-", "").ToLower();
        }

        public static String ToBase64String(String source)
        {
            byte[] toEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(source);
            string returnValue = System.Convert.ToBase64String(toEncodeAsBytes);
            return returnValue;
            //return Convert.ToBase64String(Encoding.Unicode.GetBytes(source));
        }

        public static void ClearHashTags(int scribble_id)
        {
            string sql = @"update hashtag_scribble set inactive = 1 where id_scribble = {0}";
            sql = string.Format(sql, scribble_id);
            SqlAccess.ExecuteNonQuery(sql);
        }

        public static void ProcessHashTags(string str, int scribble_id)
        {
            var regex = new Regex(@"(?:(?<=\s)|^)#(\w*[A-Za-z_]+\w*)");
            var matches = regex.Matches(str);

            foreach (Match m in matches)
            {
                string hashtag = m.Value.Replace("#",string.Empty);

                string sql = @"if not exists(select 1 from hashtags where hashtag = '{0}') 
                                insert into hashtags(hashtag) values('{0}')";

                sql = string.Format(sql, hashtag);
                SqlAccess.ExecuteNonQuery(sql);

                //insert into relationship table
                sql = @"insert into hashtag_scribble(id_hashtag, id_scribble) values((select id from hashtags where hashtag = '{0}'),{1})";
                sql = string.Format(sql, hashtag, scribble_id);
                SqlAccess.ExecuteNonQuery(sql);
            }
        }

        public static string GenerateDisqusSSOPayload(object payload)
        {
            var json = new JavaScriptSerializer().Serialize(payload);
            string timestamp = (DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0)).TotalSeconds.ToString("00");
            string message = Utilities.ToBase64String(json);
            return (message + " " + Utilities.HMACSH1(message + " " + timestamp) + " " + timestamp);
        }

        //image utilities
        private static readonly string[] _validExtensions = { "jpg", "bmp", "gif", "png" }; //  etc
        public static bool IsImageExtension(string ext)
        {
            return _validExtensions.Contains(ext);
        }

        public static bool IsValidImageContentType(string imageContentType)
        {
            var validImageTypes = new string[]
            {
                "image/gif",
                "image/jpeg",
                "image/pjpeg",
                "image/png"
            };

            return validImageTypes.Contains(imageContentType);
        }

        public static bool IsValidImage(string filename)
        {
            try
            {
                Image newImage = Image.FromFile(filename);
            }
            catch (OutOfMemoryException ex)
            {
                // Image.FromFile will throw this if file is invalid. 
                // Don't ask me why. return false; 
                return false;
            }
            return true;
        }


        public static Stream GenerateThumb(Stream sourceFileStream, int scale, bool crop)
        {
            Image imgOriginal = Image.FromStream(sourceFileStream);
            Image imgActual = ScaleBySize(imgOriginal, scale);
            if (crop)
            {
                imgActual = CropImage(imgActual, new Rectangle(0, 0, scale, scale));
            }

            EncoderParameters encoderParams = new System.Drawing.Imaging.EncoderParameters();
            long[] quality = new long[1];

            quality[0] = 75L;

            EncoderParameter encoderParam = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
            ImageCodecInfo[] encoders = ImageCodecInfo.GetImageEncoders();

            encoderParams.Param[0] = encoderParam;

            MemoryStream ms = new MemoryStream();


            imgActual.Save(ms, encoders[1], encoderParams);
            imgActual.Dispose();
            imgOriginal.Dispose();
            return ms;
        }

        public static Image CropImage(Image img, Rectangle cropArea)
        {
            Bitmap bmpImage = new Bitmap(img);
            Bitmap bmpCrop = bmpImage.Clone(cropArea, bmpImage.PixelFormat);
            //reduce file size
            return (Image)(bmpCrop);
        }

        public static Image ScaleBySize(Image imgPhoto, int size)
        {
            float sourceWidth = imgPhoto.Width;
            float sourceHeight = imgPhoto.Height;
            float destHeight = 0;
            float destWidth = 0;
            int sourceX = 0;
            int sourceY = 0;
            int destX = 0;
            int destY = 0;

            // Resize Image to have the height = logoSize/2 or width = logoSize.
            // Height is greater than width, set Height = logoSize and resize width accordingly
            if (sourceWidth < sourceHeight)
            {
                destWidth = size;
                destHeight = (float)(sourceHeight * size / sourceWidth);

            }
            else
            {
                int h = size;
                destHeight = h;
                destWidth = (float)(sourceWidth * h / sourceHeight);
            }
            // Width is greater than height, set Width = logoSize and resize height accordingly

            //always force width to be the determining factor
            //destWidth = size;
            //destHeight = (float)(sourceHeight * size / sourceWidth);

            Bitmap bmPhoto = new Bitmap((int)destWidth, (int)destHeight, PixelFormat.Format32bppPArgb);
            bmPhoto.SetResolution(imgPhoto.HorizontalResolution, imgPhoto.VerticalResolution);

            Graphics grPhoto = Graphics.FromImage(bmPhoto);
            grPhoto.SmoothingMode = SmoothingMode.AntiAlias;
            grPhoto.InterpolationMode = InterpolationMode.HighQualityBicubic;
            grPhoto.PixelOffsetMode = PixelOffsetMode.HighQuality;
            grPhoto.DrawImage(imgPhoto,
                new Rectangle(destX, destY, (int)destWidth, (int)destHeight),
                new Rectangle(sourceX, sourceY, (int)sourceWidth, (int)sourceHeight),
                GraphicsUnit.Pixel);

            grPhoto.Dispose();

            return bmPhoto;
        }

        public static void UploadImage(string filename, string filepath)
        {
            ImageBuilder.Current.Build(filepath + filename, filepath + filename.Replace(".png", ".jpg").Replace(".gif", ".jpg").Replace(" ","_"), new ResizeSettings("width=650&format=jpg"));
        }

        public static void ResizeImage(string filename, string filepath)
        {
            //String fileExt = System.IO.Path.GetExtension(filename).ToLower();
            //string ThumbPath = String.Format("~/Scribbles/{0}_t_.{1}", filename, fileExt);
            //string MediumPath = String.Format("~/Scribbles/{0}_m_.{1}", filename, fileExt);
            //string OriginalPath = String.Format("~/Scribbles/{0}_o_.{1}", filename, fileExt);

            //using (var fileStream = File.Create(HttpContext.Current.Server.MapPath(ThumbPath)))
            //{
            //    GenerateThumb(imageStream, 200, false).CopyTo(fileStream);
            //}           

            using (System.Drawing.Image Img = System.Drawing.Image.FromFile(filepath + filename))
            {
                // Get file extension
                String fileExt = System.IO.Path.GetExtension(filepath + filename).ToLower();

                string ThumbPath = String.Format("{0}t_{1}", filepath, filename);
                string MediumPath = String.Format("{0}m_{1}", filepath, filename);

                // Get thumb resolution
                int thumnbnailSize = 200;
                int mediumSize = 400;

                ImageBuilder.Current.Build(filepath + filename, ThumbPath.Replace(".png", ".jpg").Replace(".gif", ".jpg").Replace(" ", "_"), new ResizeSettings("width=250&format=jpg"));
                ImageBuilder.Current.Build(filepath + filename, MediumPath.Replace(".png", ".jpg").Replace(".gif", ".jpg").Replace(" ", "_"), new ResizeSettings("width=500&format=jpg"));


                //using (Image ImgThnail = ScaleBySize(Img,thumnbnailSize))
                //{
                //    ImgThnail.Save(ThumbPath, Img.RawFormat);
                //}
                //using (Image ImgThnail = ScaleBySize(Img, mediumSize))
                //{
                //    ImgThnail.Save(MediumPath, Img.RawFormat);
                //}
            }
        }

        public static Size NewImageSize(int OriginalHeight, int OriginalWidth, double thumbWidth, double thumbHeight)
        {
            Size NewSize;
            double tempval;
            if (OriginalHeight > thumbHeight || OriginalWidth > thumbWidth)
            {
                if (OriginalHeight > OriginalWidth)
                    tempval = thumbHeight / Convert.ToDouble(OriginalHeight);
                else
                    tempval = thumbWidth / Convert.ToDouble(OriginalWidth);

                NewSize = new Size(Convert.ToInt32(tempval * OriginalWidth),
                 Convert.ToInt32(tempval * OriginalHeight));
            }
            else
                NewSize = new Size(OriginalWidth, OriginalHeight); return NewSize;
        }
        
        //public static string[] HmacSha1Sign(byte[] keyBytes, string message)
        //{
        //    HMACSHA1 myhmacsha1 = new HMACSHA1(key);
        //    byte[] byteArray = Encoding.ASCII.GetBytes(input);
        //    MemoryStream stream = new MemoryStream(byteArray);
        //    return myhmacsha1.ComputeHash(stream).Aggregate("", (s, e) => s + String.Format("{0:x2}", e), s => s);
  

        //}

    }
}