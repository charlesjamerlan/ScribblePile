﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using scribble.Data;
using scribble.Common;

namespace scribble.Models
{
    public class HashTag
    {
        public int id { get; set; }
        public string hashtag { get; set; }
        public int hashtag_count { get; set; }

        public HashTag() { }

        public static IList<HashTag> GetHashTags(int id_scribble)
        {
            var ssql = @"select distinct id, hashtag, hashtag_count from hashtags h
                        inner join hashtag_scribble hs on h.id = hs.id_hashtag
						inner join (select count(*) as hashtag_count, id_hashtag from hashtag_scribble group by id_hashtag) hc on hc.id_hashtag = hs.id_hashtag
                        where hs.id_scribble = {0} and inactive = 0 
						and inactive = 0 order by hashtag_count desc";

            ssql = string.Format(ssql, id_scribble);
            var hashtags = Helpers.GetData<HashTag>(ssql, Create).ToList();
            return hashtags;
        }

        public static HashTag Create(IDataRecord dr)
        {
            return new HashTag
            {
                id = (int)dr["id"],
                hashtag = dr["hashtag"].ToString(),
                hashtag_count = (int)dr["hashtag_count"]
            };
        }
    }
}