﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using scribble.Data;
using scribble.Common;

namespace scribble.Models
{
    public class InvitationCode
    {
        public int id { get; set; }
        public string code { get; set; }
        public int id_user { get; set; }
        public bool redeemed { get; set; }

        public InvitationCode() { }

        public static InvitationCode Get(string invitationcode)
        {
            var ssql = @"select * from invitation_codes 
                        where code = '" + invitationcode + "' and redeemed = 0";

            var invitecode = Helpers.GetData<InvitationCode>(ssql, Create).FirstOrDefault();
            return invitecode;
        }

        public static void SetInvitationCodeRedeemed(string invitation_code, int id_user){
            string ssql2 = @"update invitation_codes set redeemed = 1, redeemed_date = GETDATE(), id_user = " + id_user.ToString() + " where code = '" + invitation_code.CleanSQL() + "' ";
            SqlAccess.ExecuteScalar(ssql2);

            string ssql3 = @"update [user] set invitation_code = '" + invitation_code.CleanSQL() + "' where id=(select id_user from invitation_codes where code='" + invitation_code.CleanSQL() + "')";
            SqlAccess.ExecuteScalar(ssql3);
        }

        public static InvitationCode GenerateInvitationCode(int id_user)
        {
            string invitecode = id_user.ToString().GetHashCode().ToString("X6");
            string ssql = "insert into invitation_codes(code, id_user, redeemed) values('" + invitecode + "', '" + id_user.ToString() + "', 0)";
            SqlAccess.ExecuteNonQuery(ssql);

            return Get(invitecode);
        }

        public static InvitationCode Create(IDataRecord dr)
        {
            return new InvitationCode
            {
                id = (int)dr["id"],
                code = dr["code"].ToString(),
                id_user = (int)dr["id_user"],
                redeemed = (bool)dr["redeemed"]
            };
        }

    }
}