﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using scribble.Data;
using scribble.Common;

namespace scribble.Models
{
    public class User
    {
        public int id { get; set; }
        public DateTime timestamp { get; set; }
        public DateTime last_login { get; set; }            
        public string username { get; set; }
        private string password { get; set; }
        public string email { get; set; }
        public int account_type { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string biography { get; set; }
        public string website { get; set; }
        public int scribble_count { get; set; }
        public string invitation_code { get; set; }
        public bool photo { get; set; }
        public string photo_name { get; set; }
        public string reset_token { get; set; }
        public bool active { get; set; }
        public bool admin { get; set; }
        public bool requested_invite { get; set; }

        public User() { }
        public User(int id){
            User u = User.Get(id);
            LoadRecord(u);
        }

        public User(string username)
        {
            User u = User.Get(username);
            LoadRecord(u);
        }

        private void LoadRecord(User u){
            this.id = u.id;
            this.username = u.username;
            this.firstname = u.firstname;
            this.lastname = u.lastname;
            this.email = u.email;
            this.biography = u.biography;
            this.scribble_count = u.scribble_count;
            this.photo = u.photo;
            this.photo_name = u.photo_name;
            this.reset_token = u.reset_token;
            this.admin = u.admin;
            this.active = u.active;
            this.requested_invite = u.requested_invite;
        }

        public void SignUp()
        {
            string ssql = "insert into [user](username, password, email, invitation_code) values('" + this.username.CleanSQL() + "', '" + this.password.CleanSQL() + "','" + this.email.CleanSQL() + "', '" + this.invitation_code.CleanSQL() + "') ";
            SqlAccess.ExecuteNonQuery(ssql);
        }

        public void SetResetToken()
        {
            string token = Guid.NewGuid().ToString();
            string ssql = "update [user] set reset_token = '" + token + "' where id='" + this.id.ToString() + "' ";
            SqlAccess.ExecuteNonQuery(ssql);
            this.reset_token = token;
        }

        public void UpdateProfile(){
            string ssql = @"update [user] 
                                set username = '{1}',
                                    firstname = '{2}',
                                    lastname = '{3}',
                                    biography = '{4}',
                                    email = '{5}',
                                    website = '{6}',
                                    photo = {7}
                                where id={0}";

            ssql = string.Format(ssql, this.id, this.username.CleanSQL(), this.firstname.CleanSQL(), this.lastname.CleanSQL(), this.biography.CleanSQL(), this.email.CleanSQL(), this.website.Replace("http://", "").CleanSQL(), this.photo ? 1 : 0);
            SqlAccess.ExecuteNonQuery(ssql);
        }

        public void UpdateCounts()
        {
            string ssql = @"update [user] 
                                set scribble_count = (select count(*) from scribble where id_user={0} and active = 1)
                                where id={0}";

            ssql = string.Format(ssql, this.id);
            SqlAccess.ExecuteNonQuery(ssql);
        }

        public IList<User> GetListOfFollowing()
        {
            var ssql = @"select * 
                        from user_following uf
                        join [user] u on uf.id_user_following = u.id
                        where uf.id_user = {0}";

            ssql = string.Format(ssql, this.id);
            var users = Helpers.GetData<User>(ssql, Create).ToList();
            return users;
        }
        public IList<User> GetListOfFollowers()
        {
            var ssql = @"select * 
                        from user_following uf
                        join [user] u on uf.id_user_following = u.id
                        where uf.id_user_following = {0}";

            ssql = string.Format(ssql, this.id);
            var users = Helpers.GetData<User>(ssql, Create).ToList();
            return users;
        }

        public static int Login(string username, string password)
        {
            string sql = @"select * from [user] where username='" + username.CleanSQL() + "' and password='" + password.CleanSQL() + "'";
            var user = Helpers.GetData<User>(sql, Create);
            if (user.Count() > 0)
            {
                return user.First().id;
            }
            else
            {
                return 0;
            }
            
        }

        public static int Register(string username, string firstname, string lastname, string password, string email, string invitation_code)
        {
            string ssql = @"insert into [user](username, firstname, lastname, password, email, invitation_code) values('{0}', '{1}','{2}','{3}', '{4}', '{5}')                         
                            select @@identity";
            ssql = string.Format(ssql, username.CleanSQL(), firstname.CleanSQL(), lastname.CleanSQL(), password.CleanSQL(), email.CleanSQL(), invitation_code.CleanSQL());

            return int.Parse(SqlAccess.ExecuteScalar(ssql).ToString());            
        }

        public static void SetAccountType(int account_type, int userid)
        {
            string ssql = @"update [user] set account_type={1} where id={0}";
            ssql = string.Format(ssql, userid, account_type);
            SqlAccess.ExecuteScalar(ssql);
        }

        public static void ChangePassword(string password, int userid)
        {
            string ssql = @"update [user] set password='{0}' where id='{1}'";
            ssql = string.Format(ssql, password.CleanSQL(), userid);
            SqlAccess.ExecuteScalar(ssql);
        }      


        public static bool ValidInvitationCode(string invitation_code)
        {
            string ssql = @"select count(*) from invitation_codes where code = '" + invitation_code.CleanSQL() + "' and redeemed=0 "; 
            return int.Parse(SqlAccess.ExecuteScalar(ssql).ToString()) == 0 ? false : true;
        }

        public static void MarkAsRequested(string username)
        {
            string ssql = @"update [user] set requested_invite = 1 where username='" + username + "'";
            SqlAccess.ExecuteNonQuery(ssql);
        }

        public static void ApproveRequest(int id)
        {
            string ssql = @"update [user] set requested_invite = 0 where id='" + id.ToString() + "'";
            SqlAccess.ExecuteNonQuery(ssql);
        }

        public static InvitationCode GetUserValidInvitationCode(string invitation_code)
        {
            InvitationCode invitecode = InvitationCode.Get(invitation_code);
            return invitecode;
        }

        public static bool UsernameExists(string username)
        {
            string ssql = @"select count(*) from [user] where username = '" + username.CleanSQL() + "' ";
            return int.Parse(SqlAccess.ExecuteScalar(ssql).ToString()) == 0 ? false : true;
        }

        public static bool EmailExists(string email)
        {
            string ssql = @"select count(*) from [user] where email = '" + email.CleanSQL() + "' ";
            return int.Parse(SqlAccess.ExecuteScalar(ssql).ToString()) == 0 ? false : true;
        }     

        public static User Get(string username)
        {
            var ssql = @"select * from [user] 
                        where username = '" + username.CleanSQL() + "'";

            var obj = Helpers.GetData<User>(ssql, Create);
            User user = new User();
            if (obj.Count() > 0)
            {
                user = Helpers.GetData<User>(ssql, Create).First();
            }
            return user;
        }

        public static User Get(int id_user)
        {
            var ssql = @"select * from [user] 
                        where id = " + id_user.ToString();

            var obj = Helpers.GetData<User>(ssql, Create);
            User user = new User();
            if (obj.Count() > 0)
            {
                user = Helpers.GetData<User>(ssql, Create).First();
            }
            return user;
        }

      

        public static IList<User> GetListOfUsersPendingRequest()
        {
            var ssql = @"select * from [user] where requested_invite = 1 and active = 1";
            var users = Helpers.GetData<User>(ssql, Create).ToList();
            return users;
        }


        public static User Create(IDataRecord dr)
        {
            return new User
            {
                id = (int)dr["id"],
                timestamp = (DateTime)dr["timestamp"],
                username = dr["username"].ToString(),
                email = dr["email"].ToString(),
                firstname = dr["firstname"].ToString(),
                lastname = dr["lastname"].ToString(),
                biography = dr["biography"].ToString(),
                website = dr["website"].ToString(), 
                scribble_count = (int)dr["scribble_count"],
                photo = (bool)dr["photo"],
                photo_name = (bool)dr["photo"] ? dr["id"].ToString() + ".jpg" : "default.png",
                reset_token = dr["reset_token"].ToString(),
                account_type = (int)dr["account_type"],
                active = (bool)dr["active"],
                admin = (bool)dr["admin"],
                requested_invite = (bool)dr["requested_invite"]
            };
        }
    }
}