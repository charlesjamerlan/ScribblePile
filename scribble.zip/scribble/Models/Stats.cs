﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using scribble.Data;
using System.Data;

namespace scribble.Models
{
    public class Stats
    {

        public static int GetUsers()
        {
            string ssql = "select count(*) from [user] where active = 1";
            return (int)SqlAccess.ExecuteScalar(ssql);
        }

        public static int GetAuthors()
        {
            string ssql = "select count(*) from [user] where active = 1 and account_type = 1";
            return (int)SqlAccess.ExecuteScalar(ssql);
        }


        public static int GetScribbles()
        {
            string ssql = "select count(*) from scribble where active = 1";
            return (int)SqlAccess.ExecuteScalar(ssql);
        }

        public static int GetPendingRequests()
        {
            string ssql = "select count(*) from [user] where active = 1 and requested_invite = 1";
            return (int)SqlAccess.ExecuteScalar(ssql);
        }

        
    }
}