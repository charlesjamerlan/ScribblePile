﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using scribble.Data;
using scribble.Common;

namespace scribble.Models
{
    public class CommissionInformation
    {
        public int id { get; set; }
        public int id_author { get; set; }
        public int status { get; set; }
        public string information { get; set; }

        public CommissionInformation() { }

        public static CommissionInformation GetCommissionInformation(int id_user)
        {
            var ssql = @"select * from commission_information where id_user = '{0}'";

            ssql = string.Format(ssql, id_user);
            var commissioninfo = Helpers.GetData<CommissionInformation>(ssql, Create).FirstOrDefault();
            return commissioninfo;
        }

        public static CommissionInformation Create(IDataRecord dr)
        {
            return new CommissionInformation
            {
                id = (int)dr["id"],
                id_author = (int)dr["id_author"],
                status = (int)dr["status"],
                information = dr["information"].ToString()
            };
        }
    }
}