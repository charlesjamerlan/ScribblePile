﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using scribble.Data;

namespace scribble.Models
{
    public class Favorite
    {
        public DateTime timestamp { get; set; }
        public int id_scribble { get; set; }
        public int id_user { get; set; }

        public Favorite() { }

        public static bool IsFavorited(int id_scribble, int id_user)
        {
            string ssql = "select count(*) from favorites where id_scribble = " + id_scribble.ToString() + " and id_user=" + id_user.ToString();
            return ((int)SqlAccess.ExecuteScalar(ssql) == 0) ? false : true;
        }

        public static int GetFavoriteCount(int id_scribble)
        {
            var ssql = @"select count(*) from favorites 
                        where id_scribble = " + id_scribble.ToString();

            int likecount = (int)SqlAccess.ExecuteScalar(ssql);
            return likecount;
        }      
        public static void SaveFavorite(int id_scribble, int id_user)
        {
            string ssql = "if not exists (select id_scribble from favorites where id_scribble = " + id_scribble.ToString() + " and id_user=" + id_user.ToString() + ") insert into favorites(id_scribble, id_user) values(" + id_scribble.ToString() + ", " + id_user.ToString() + ") ";
            SqlAccess.ExecuteNonQuery(ssql);
        }

        public static void RemoveFavorite(int id_scribble, int id_user)
        {
            string ssql = "delete from favorites where id_scribble = " + id_scribble.ToString() + " and id_user=" + id_user.ToString();
            SqlAccess.ExecuteNonQuery(ssql);
        }       

    }
}