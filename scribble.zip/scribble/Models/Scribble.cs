﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using scribble.Data;
using System.Data;
using System.Data.SqlClient;
using scribble.Common;
using Dapper;

namespace scribble.Models
{
    public class ScribbleThumb
    {
        public int id {get;set;}
        public string title { get; set; }
        public string description { get; set; }
        public string filename { get; set; }

        public static IList<ScribbleThumb> GetScribbleThumbsByUser(int id_user, int id_scribble)
        {
            var ssql = @"select top 10 s.id, title, s.description, v.filename
                            from scribble s
                            inner join version v on s.id_version_latest = v.id
                            where s.id_user = '" + id_user.ToString() + "' and s.active = 1 and s.id <> '" + id_scribble.ToString() + "' order by s.id desc";


            var scribbles = Helpers.GetData<ScribbleThumb>(ssql, Create).ToList();
            return scribbles;
        }

        public static ScribbleThumb Create(IDataRecord dr)
        {
            return new ScribbleThumb
            {
                id = (int)dr["id"],
                title = dr["title"].ToString(),
                description = dr["description"].ToString(),
                filename = dr["filename"].ToString()
            };
        }     
    }

    public class Scribble
    {
        public int id { get; set; }
        public int id_author { get; set; }
        public User author { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public string identifier { get; set; }
        public IList<Version> versions { get; set; }
        public IList<HashTag> hashtags { get; set; }
        public int views { get; set; }
        public int likes { get; set; }
        public int comments { get; set; }
        public bool active { get; set; }

        public Scribble() { }

        public int Add()
        {
            var ssql = @"insert into scribble(id_user, title, description) values({0},'{1}','{2}') 
                         select @@identity";

            ssql = string.Format(ssql, this.id_author.ToString(), this.title.CleanSQL(), this.description.CleanSQL());
            return int.Parse(SqlAccess.ExecuteScalar(ssql).ToString());            
        }

        public void Save()
        {
            var ssql = @"update scribble 
                            set title='{1}',
                                description='{2}'
                         where id={0}";

            ssql = string.Format(ssql, this.id.ToString(), this.title.CleanSQL(), this.description.CleanSQL());
            SqlAccess.ExecuteNonQuery(ssql);
        }


        public void Delete()
        {
            var ssql = @"update scribble 
                        set active = 0
                        where id = " + this.id.ToString();
            SqlAccess.ExecuteNonQuery(ssql);
        }

        public static Scribble Get(string id_scribble)
        {
            var ssql = @"select * from scribble 
                        where id = " + id_scribble.ToString();

            Scribble scribble = new Scribble();
            var obj = Helpers.GetData<Scribble>(ssql, Create);
            if (obj.Count() > 0){
                scribble = obj.First();
            }
            return scribble;
        }

        public static int GetVersionCount(int id_scribble)
        {
            var ssql = @"select count(*) from version where id_scribble='" + id_scribble.ToString() + "' and active=1 ";
            return (int)SqlAccess.ExecuteScalar(ssql);
        }

        public static void UpdateCommentCount(int id_scribble)
        {
            var ssql = @"update scribble set comments = comments + 1 where id='" + id_scribble.ToString() + "' ";
            SqlAccess.ExecuteNonQuery(ssql);
        }


        public static IList<Scribble> GetScribblesMostRecent(int start)
        {
            int perpage = int.Parse(System.Configuration.ConfigurationManager.AppSettings["PerPage"]);
            var ssql = @"spGetScribbleMostRecent @start={0}, @perpage={1}";
            ssql = string.Format(ssql, start, perpage);

            var scribbles = Helpers.GetData<Scribble>(ssql, Create).ToList();
            return scribbles;
        }


        public static IList<Scribble> GetScribblesMostPopular(int start)
        {
            int perpage = int.Parse(System.Configuration.ConfigurationManager.AppSettings["PerPage"]);
            var ssql = @"spGetScribbleMostPopular @start={0}, @perpage={1}";
            ssql = string.Format(ssql, start, perpage);

            var scribbles = Helpers.GetData<Scribble>(ssql, Create).ToList();
            return scribbles;
        }


        public static IList<Scribble> GetScribblesByHashTag(int start, string hashtag)
        {
            int perpage = int.Parse(System.Configuration.ConfigurationManager.AppSettings["PerPage"]);
            var ssql = @"spGetScribbleHashTag @start={0}, @perpage={1}, @hashtag='{2}'";
            ssql = string.Format(ssql, start, perpage, hashtag);

            var scribbles = Helpers.GetData<Scribble>(ssql, Create).ToList();
            return scribbles;
        }


        public static IList<Scribble> GetScribblesByUser(int id_user, int start)
        {
//            var ssql = @"select * from scribble 
//                        where id_user = " + id_user.ToString() + " order by id desc";

            int perpage = int.Parse(System.Configuration.ConfigurationManager.AppSettings["PerPage"]);
            var ssql = @"spGetScribbleByUser @id_user={0}, @start={1}, @perpage={2}";
            ssql = string.Format(ssql, id_user, start, perpage);
            var scribbles = Helpers.GetData<Scribble>(ssql, Create).ToList();
            return scribbles;
        }

        public static IList<Scribble> GetScribblesFavorteByUser(int id_user, int start)
        {
            //            var ssql = @"select * from scribble 
            //                        where id_user = " + id_user.ToString() + " order by id desc";

            int perpage = int.Parse(System.Configuration.ConfigurationManager.AppSettings["PerPage"]);
            var ssql = @"spGetScribbleFavoritesByUser @id_user={0}, @start={1}, @perpage={2}";
            ssql = string.Format(ssql, id_user, start, perpage);

            var scribbles = Helpers.GetData<Scribble>(ssql, Create).ToList();
            return scribbles;
        }


        public static Scribble Create(IDataRecord dr)
        {
            return new Scribble
            {
                id = (int)dr["id"],
                id_author = (int)dr["id_user"],
                author = User.Get((int)dr["id_user"]),
                title = dr["title"].ToString(),
                description = dr["description"].ToString(),
                identifier = String.Format("{0:X}", (int)dr["id"].ToString().GetHashCode()),
                versions = Version.GetVersions((int)dr["id"]),
                hashtags = HashTag.GetHashTags((int)dr["id"]),
                views = (int)dr["views"],
                likes = Like.GetLikeCount((int)dr["id"]),
                comments = (int)dr["comments"],
                active = (bool)dr["active"]
            };
        }       

    }
}