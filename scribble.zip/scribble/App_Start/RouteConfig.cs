﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace scribble
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.MapRoute(
            "ScribbleAdd",
            "scribble/add",
            new { controller = "Scribble", action = "Add"}
            );

            routes.MapRoute(
            "ScribbleSaveUploadedFile",
            "scribble/SaveUploadedFile",
            new { controller = "Scribble", action = "SaveUploadedFile" }
            );

            routes.MapRoute(
                "Scribble",
                "scribble/{id_scribble}/{action}",
                new { controller = "Scribble", action = "Get", id_scribble = (string)null }
                );

            routes.MapRoute(
                "About",
                "about",
                new { controller = "Content", action = "About"}
                );

            routes.MapRoute(
                "Terms",
                "terms",
                new { controller = "Content", action = "terms" }
                );

            routes.MapRoute(
                "Privacy",
                "privacy",
                new { controller = "Content", action = "privacy" }
                );

            routes.MapRoute(
                "UserFavorites",
                "user/{id_user}/favorites",
                new { controller = "User", action = "Favorites", id_scribble = (string)null }
                );


            routes.MapRoute(
                "CommissionList",
                "user/{id_user}/commission/list",
                new { controller = "User", action = "CommissionList", id_scribble = (string)null }
                );

            routes.MapRoute(
                "CommissionRequest",
                "user/{id_user}/commission/request",
                new { controller = "User", action = "CommissionRequest", id_scribble = (string)null }
                );

            routes.MapRoute(
                "User",
                "user/{id_user}/{action}",
                new { controller = "User", action = "Get", id_scribble = (string)null }
                );

            routes.MapRoute(
                "Login",
                "login/{action}",
                new { controller = "Login", action = "Index" }
                );

            routes.MapRoute(
                "ChangePassword",
                "changepassword/{action}",
                new { controller = "ChangePassword", action = "Index" }
                );

            routes.MapRoute(
                "Register",
                "register/{action}",
                new { controller = "Register", action = "Index" }
                );

            routes.MapRoute(
                "Latest",
                "latest",
                new { controller = "Home", action = "Latest" }
                );

            routes.MapRoute(
                "Popular",
                "popular",
                new { controller = "Home", action = "Popular" }
                );

            routes.MapRoute(
                "HashTags",
                "hashtags/{tag}",
                new { controller = "Home", action = "HashTags", tag = (string)null }
                );

            routes.MapRoute(
                "Admin",
                "admin/{action}",
                new { controller = "Admin", action = "Stats" }
                );


            routes.MapRoute(
                "UserName",
                "{id_user}/{action}",
                new { controller = "User", action = "Get", id_scribble = (string)null }
                );

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}